from openai import OpenAI
from config import OPENAI_API_KEY
import re

# Initialize OpenAI client
client = OpenAI(api_key=OPENAI_API_KEY)

def generate_personalized_email(company_name, company_info, person_name, person_headline, person_about, person_position):
    prompt = f"""
    You are an cold email expert in writing friendly and casual and to the point emails. Your task is to generate a short casual personalized cold email on behalf of Krishna Kumar Soni, based on the following company information, founder details, and the design agency's capabilities.

    Company Name:
    {company_name}

    Company Information:
    {company_info}

    Founder's Name:
    {person_name}

    Founder's Headline:
    {person_headline}

    Founder's About:
    {person_about}

    Design Agency Information:
    - Kuberanix is a design agency where we develop brand identity, brand strategy and UI/UX designs
    - We have helped 15+ founders in growing their business using our product, branding and design skills. 
    - We have worked with global brands and companies.
    - My name is Krishna Kumar Soni. I am the founder of Kuberanix. Kuberanix website is kuberanix.com. 

    Call to action: Ask the potential client if they'd be interested in a free 30 minute call to discuss a brand & UI/UX design audit of their company.

    Email closing: 
    Warm Regards,
    Krishna Kumar Soni
    Indian Institute of Technology, Kharagpur
    Founder, Kuberanix
    www.kuberanix.com
    
    Writing style: conversational, casual, engaging, simple to read, simple linear active voice sentences, informational and insightful.
    
    Use the following formulas to write effective cold emails for a design agency:

    1. AIDA: Start with an attention-grabbing subject line or opening sentence. Highlight the recipient's pain points to build interest. List the benefits and use social proof, scarcity, or exclusivity to create desire. End with a specific call to action.

    2. BBB: Keep the email brief, blunt, and basic. Shorten the email, get straight to the point, and use simple language.

    3. PAS: Identify a sore point (Problem). Emphasize the severity with examples or personal experience (Agitate). Present your solution (Solve).

    4. QVC: Start with a question. Highlight what makes you unique (Value Proposition). End with a strong call to action.

    5. PPP: Open with a genuine compliment (Praise). Show how your product/service helps (Picture). Encourage them to take action (Push).

    6. SCH: Introduce your product or idea (Star). Provide strong facts and reasons (Chain). End with a powerful call to action (Hook).

    7. SSS: Introduce the star of your story (Star). Describe the problem they face (Story). Explain how your product solves the problem (Solution).

    8. RDM: Use facts (Fact-packed), be brief (Telegraphic), be specific (Specific), avoid too many adjectives (Few adjectives), and make them curious (Arouse curiosity).

    These formulas will help you craft concise, casual, friendly engaging, and compelling cold emails.

    """

    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ]
    )
    
    email_text = response.choices[0].message.content.strip()
    return email_text


def extract_email_body(email_text):
    # Define the start pattern for the email body
    start_pattern = re.compile(r"^(Hi|Hello|Dear|Greetings|Hey|Hope).*$", re.IGNORECASE | re.MULTILINE)
    
    # Define the end pattern for the email body
    end_pattern = re.compile(
        r"(Best regards,|Regards,|Sincerely,|Thank you,|Thanks,|Warm regards,|Warm Regards,|Thank You,|Best Regards,|Cheers,)",
        re.IGNORECASE
    )

    # Remove various possible subject lines
    email_text = re.sub(r"^Subject(?: Line)?:.*\n", "", email_text, flags=re.IGNORECASE | re.MULTILINE)

    # Find the start of the email
    start_match = start_pattern.search(email_text)
    if start_match:
        email_text = email_text[start_match.start():]

    # Split the email into lines
    lines = email_text.splitlines()

    # Find the end of the email
    end_match = end_pattern.search(email_text)
    if end_match:
        end_index = email_text.count('\n', 0, end_match.start())
        ending_lines = lines[end_index:]
        
        # Check the number of lines in the ending part
        if len(ending_lines) > 6:
            # Check for "PS" in the first 6 lines of the ending part
            ps_found = any('PS' in line for line in ending_lines[:6])
            if ps_found:
                email_text = '\n'.join(lines[:end_index + len(ending_lines[-6:])])
            else:
                email_text = '\n'.join(lines[:end_index + 6])
        else:
            email_text = '\n'.join(lines[:end_index + len(ending_lines)])

    return email_text.strip()


def convert_to_html(plain_text):
    prompt = f"""
    Convert the following plain text email to HTML. Ensure to handle new line breaks with <br> tags and make links clickable.

    Plain Text:
    {plain_text}

    Use only br and anchor tags and no other html element. Respond with just the converted content.
    """
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": prompt}
        ]
    )
    response_content = response.choices[0].message.content.strip()

    # Ensure to handle new line breaks with <br> tags and make links clickable.
    html_content = re.sub(r'\n', '<br>', response_content)
    html_content = re.sub(r'(\bhttps?://[^\s]+)', r'<a href="\1">\1</a>', html_content)

    return html_content