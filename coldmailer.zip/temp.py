import re

def extract_email_body(email_text):
    # Define the start pattern for the email body
    start_pattern = re.compile(r"^(Hi|Hello|Dear|Greetings|Hey|Hope).*$", re.IGNORECASE | re.MULTILINE)
    
    # Define the end pattern for the email body
    end_pattern = re.compile(
        r"(Best regards,|Regards,|Sincerely,|Thank you,|Thanks,|Warm regards,|Warm Regards,|Thank You,|Best Regards,|Cheers,)",
        re.IGNORECASE
    )

    # Remove various possible subject lines
    email_text = re.sub(r"^Subject(?: Line)?:.*\n", "", email_text, flags=re.IGNORECASE | re.MULTILINE)

    # Find the start of the email
    start_match = start_pattern.search(email_text)
    if start_match:
        email_text = email_text[start_match.start():]

    # Split the email into lines
    lines = email_text.splitlines()

    # Find the end of the email
    end_match = end_pattern.search(email_text)
    if end_match:
        end_index = email_text.count('\n', 0, end_match.start())
        ending_lines = lines[end_index:]
        
        # Check the number of lines in the ending part
        if len(ending_lines) > 6:
            # Check for "PS" in the first 6 lines of the ending part
            ps_found = any('PS' in line for line in ending_lines[:6])
            if ps_found:
                email_text = '\n'.join(lines[:end_index + len(ending_lines[-6:])])
            else:
                email_text = '\n'.join(lines[:end_index + 6])
        else:
            email_text = '\n'.join(lines[:end_index + len(ending_lines)])

    return email_text.strip()

# Test the function with provided input
email_text = """
Sure! Based on your details, here's a cold email using the PPP (Praise, Picture, Push) formula:

---

**Subject**: Let’s Simplify Sustainability Together! 🚀

Hi Paul,

I’m truly amazed by what Natural Capital Associates is achieving in terms of sustainable growth and environmental conservation. Your commitment to preserving natural ecosystems while fostering profitable ventures is genuinely inspiring!

At Kuberanix, we understand the enormous influence a strong brand identity and seamless UX can have on amplifying your mission. With extensive experience helping over 15 founders, we specialize in creating brand strategies and UI/UX designs that resonate with global audiences.

Would you be interested in a free 30-minute call to discuss a brand and UI/UX design audit for Natural Capital Associates? We could explore how to enhance your online presence and communicate your powerful mission to a broader audience.

Looking forward to connecting!

Warm Regards,
Krishna Kumar Soni
Indian Institute of Technology, Kharagpur

PS: I also watch the same show!

-------

This is your required email!
"""

extracted_email = extract_email_body(email_text)
print(extracted_email)
