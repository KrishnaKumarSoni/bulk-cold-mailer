import os
import pandas as pd
import logging
import gspread
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from config import GOOGLE_SHEETS_CREDENTIALS
import time

# Logging configuration
logging.basicConfig(level=logging.INFO)

# Setup Google Sheets API client
SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive.metadata.readonly'
]

def authenticate_google_sheets():
    creds = None
    token_path = 'token.json'
    credentials_path = GOOGLE_SHEETS_CREDENTIALS

    if not credentials_path:
        raise ValueError("The credentials path is not set. Please check your .env file.")

    print(f"Using Google Sheets Credentials Path: {credentials_path}")

    # If token.json exists, load it
    if os.path.exists(token_path):
        creds = Credentials.from_authorized_user_file(token_path, SCOPES)
    
    # If there are no valid credentials available, request the user to log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
            logging.info("Refreshed OAuth token")
        else:
            flow = InstalledAppFlow.from_client_secrets_file(credentials_path, SCOPES)
            creds = flow.run_local_server(port=8080)
            logging.info("Created new OAuth token")
        
        # Save the credentials for the next run
        with open(token_path, 'w') as token:
            token.write(creds.to_json())
            logging.info("Saved OAuth token to file")

    logging.info(f"Scopes granted: {creds.scopes}")
    client = gspread.authorize(creds)
    return client, creds

def search_sheets(creds, search_string):
    service = build('drive', 'v3', credentials=creds)
    query = f"name contains '{search_string}' and mimeType='application/vnd.google-apps.spreadsheet'"
    results = service.files().list(q=query, fields="nextPageToken, files(id, name)").execute()
    items = results.get('files', [])
    
    if not items:
        print(f"No files found matching '{search_string}'. Please try again.")
        return []
    
    for idx, item in enumerate(items):
        print(f"{idx}: {item['name']} ({item['id']})")

    return items

def select_sheet(client, creds):
    logging.info("Fetching your Google Sheets...")

    while True:
        search_string = input("Enter the search string to find your Google Sheet: ")
        sheet_list = search_sheets(creds, search_string)

        if not sheet_list:
            continue

        sheet_idx = int(input("Select the sheet number: "))
        sheet = client.open_by_key(sheet_list[sheet_idx]['id'])
        
        logging.info("Fetching worksheets...")
        worksheets = sheet.worksheets()
        for idx, ws in enumerate(worksheets):
            print(f"{idx}: {ws.title}")
        
        ws_idx = int(input("Select the worksheet number: "))
        worksheet = sheet.get_worksheet(ws_idx)
        
        return worksheet

def fetch_sheet_data(worksheet):
    # Fetch all data from the worksheet
    data = worksheet.get_all_records()
    # Convert to DataFrame for easier manipulation
    df = pd.DataFrame(data)
    return df

def update_sheet(worksheet, row, col, value):
    retries = 5
    for attempt in range(retries):
        try:
            worksheet.update_cell(row, col, value)
            logging.info(f"Updated cell at row {row}, col {col} with value: {value}")
            return
        except gspread.exceptions.APIError as e:
            if attempt < retries - 1:
                wait = 2 ** attempt  # Exponential backoff
                logging.warning(f"APIError: {e}. Retrying in {wait} seconds...")
                time.sleep(wait)
            else:
                logging.error(f"APIError: {e}. Failed after {retries} retries.")
                raise

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    client, creds = authenticate_google_sheets()
    worksheet = select_sheet(client, creds)
    df = fetch_sheet_data(worksheet)
    # Continue with your processing logic here...
