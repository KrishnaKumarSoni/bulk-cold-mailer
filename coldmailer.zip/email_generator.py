from openai_client import generate_personalized_email, convert_to_html
import logging

def create_email(company_name, company_info, contact_person, person_headline, person_about, person_position):
    # Generate personalized outreach email using GPT-3.5
    personalized_email = generate_personalized_email(company_name, company_info, contact_person, person_headline, person_about, person_position)
    logging.info(f"Generated personalized email for {company_name}")

    # Convert plain text email to HTML
    html_email = convert_to_html(personalized_email)
    return personalized_email, html_email
